# How to Add Authentication with Google Authenticator in Node.js

Code for [How to Add Authentication with Google Authenticator in Node.js tutorial](https://blog.shahednasser.com/how-to-add-authentication-with-google-authenticator-in-node-js/)

## Installation

After cloning this repository, install the dependencies:

```bash
npm i
```

## Run the Server

Run the server with the following command:

```bash
npm start
```

The server will run at `localhost:3000`.
